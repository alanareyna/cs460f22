/*******************************************************************************
* Project: Project 3 - Object class		                                       *
* Author: Dr. Watts  														   *
* Modified by: Alana Reyna                                                     *
* Date: December 16, 2022                                                      *
* File: Object.cpp, Object.h                                                   *
* Description: Object class for Scheme to C++ translation.                     *
*******************************************************************************/

what works:
Implementing the rational class within the Object class works

what does not work:
I was unable to get the #t and #f boolean operators to work properly. 